﻿using System;

namespace Desafio.BL
{
    public class Class1
    {
    }
}
