﻿using System;

namespace Desafio.Entities
{
    public class Class1
    {
    }
}
